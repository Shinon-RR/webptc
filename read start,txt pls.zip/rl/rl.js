import chalk from 'chalk';
import figlet from 'figlet';
import readlineSync from 'readline-sync';
// import { workerData } from 'worker_threads';

//일단은 변수
let name = 'name';
let wepo = 'name';
let zcal = 0;
let tsmon = '';

var p1 = {
    name: "aris",

    gold: 0,

    class: 'warrior',

    //장비를 장착하면 오르는 + 스탯
    jbhp: 0,
    jbmp: 0,
    jbdmg: 0,
    jbdef: 0,
    jbspd: 0,
    jbhwp: 0,

    //장비를 장착하면 오르는 * 스탯
    xhp: 1,
    xmp: 1,
    xdmg: 1,
    xdef: 1,
    xspd: 1,

    //최종 스탯
    fhp: 0,
    fmp: 0,
    fdmg: 0,
    fdef: 0,
    fspd: 0,
    fhwp: 0,

    //플레이어 기본 스탯
    hp: 100,
    mp: 100,
    dmg: 20,
    def: 5,
    spd: 6,
    hwp: 0,

    xhpzen: 1,
    xmpzen: 1,
    hpzen: 2,
    mpzen: 5,


    //기본은 1레벨
    lv: 30,
    exp: 0,
    maxsch: 0,

    //전투중 사용하는 스탯
    zhp: 0,
    zmp: 0,
    zdmg: 0,
    zdef: 0,
    zspd: 0,

    zsj: 0,
    zshi: 0,
    zhk: "",


    //착용중인 장비
    hat: "h0",
    armor: "a0",
    shoes: "s0",
    gloves: "g0",
    pendant: "p1",
    wepon: "w0",

    item: [],
}

//장비했을 경우 스탯 계산
function checkitem() {

    p1.jbhp = 0
    p1.jbmp = 0
    p1.jbdmg = 0
    p1.jbdef = 0
    p1.jbspd = 0
    p1.jbhwp = 0

    p1.xhp = 1
    p1.xmp = 1
    p1.xdmg = 1
    p1.xdef = 1
    p1.xspd = 1

    p1.zsj = 0

    //h시리즈는 투구
    if (p1.hat === "h1") {
        p1.jbdef += 2
    }

    //a시리즈는 갑옷
    if (p1.armor === "a1") {
        p1.xhp++
    }

    //s시리즈는 신발
    if (p1.shoes === "s1") {
        //자신의 체력이 적보다 낮을 경우 공격속도 + 5

    }

    //g시리즈는 장갑
    if (p1.gloves === "g1") {
        //적에게 가하는 데미지 계산시 10% 확률로 데미지 2배

    }

    //p시리즈는 펜던트
    if (p1.pendant === "p1") {
        if (p1.hat === "h1" && p1.armor === "a1" && p1.shoes === "s1" && p1.gloves === "g1" && p1.wepon === "w1") {
            p1.jbhp += 10
            p1.jbmp += 10
            p1.jbdmg += 10
            p1.jbdef += 10
            p1.jbspd += 10
        }
    }

    //코어의 4냥꾼 시리즈
    if (p1.hat === "h4") {
        p1.jbspd += 2
    }
    if (p1.armor === "a4") {
        p1.jbdef += 1
        p1.jbspd += 2
    }
    if (p1.shoes === "s4") {
        p1.jbdef += 2
    }
    if (p1.gloves === "g4") {
        p1.jbspd += 2
    }
    if (p1.pendant === "p4") {
        p1.jbdmg += 2
        p1.jbspd += 2
    }
    if (p1.wepon === "wa4") {
        p1.jbdmg += 10
    }



    //w시리즈는 무기
    if (p1.wepon === "w1") {
        p1.jbdmg += 10
    }
    if (p1.wepon === "ww1") {
        p1.jbdmg += 5
    }
    if (p1.wepon === "wd1") {
        p1.jbdef += 5
    }
    if (p1.wepon === "wm1") {
        p1.jbdmg += 3
        p1.jbmp += 10
    }
    if (p1.wepon === "wr1") {
        p1.jbspd += 5
    }
    if (p1.wepon === "wa1") {
        p1.jbdmg += 7
    }

    //패시브
    if (p1.class === 'warrior') {
        p1.xhp += 0.5
        p1.jbdmg += 1
        p1.xhpzen += 0.5
    }
    if (p1.class === 'defender') {
        p1.jbdef += p1.lv + (p1.dmg * 0.5)
    }
    if (p1.class === 'magiccaster') {
        p1.xmp++
        p1.xmpzen++
    }
    if (p1.class === 'rogue') {
        p1.xspd += 0.5
        p1.xhp -= 0.5
        p1.jbhwp += 35
    }
    if (p1.class === 'archer') {
        p1.xdmg += 0.2
        p1.zsj = 1
    }
    if (p1.lv >= 1) { p1.maxsch = 1 }
    if (p1.lv >= 5) { p1.maxsch = 2 }
    if (p1.lv >= 10) { p1.maxsch = 3 }
    if (p1.lv >= 20) { p1.maxsch = 4 }
    if (p1.lv >= 30) { p1.maxsch = 5 }

    p1.fhp = (p1.hp + p1.jbhp) * p1.xhp
    p1.fmp = (p1.mp + p1.jbmp) * p1.xmp
    p1.fdmg = (p1.dmg + p1.jbdmg) * p1.xdmg
    p1.fdef = (p1.def + p1.jbdef) * p1.xdef
    p1.fspd = (p1.spd + p1.jbspd) * p1.xspd
    p1.fhwp = (p1.hwp + p1.jbhwp)



}

//아이템 목록
// var ish1 = 2;

const wolf = {
    name: '늑대',
    art: 'wolf',
    hp: 100,
    spd: 5,
    dmg: 10,
    def: 5,
    hk: "",
    tk1: '"으르릉"',
    tk2: '"깨갱"',
    exp: 1,
    gold: 1,

    atk(crd, cal, cmhp, chp, cdmg, chkc, chk) {
        fui(cart)
        if (crd < 60) {
            //몬스터 기본공격
            anitext("늑대의 깨물기!", 0.1, 'c', 1);
            fui('w.q')
            anitext('"아그작"', 0.1, 'w', 2);
            cal = cdmg - p1.zdef
            mzcaca(cal)

        } else if (crd < 90) {
            //몬스터 1스킬
            fui(cart)
            anitext("늑대의 할퀴기!", 0.1, 'c', 0.5);
            fui('w.w')
            anitext('"크아앙"', 0.1, 'w', 2);
            cal = (cdmg * 2) - p1.zdef
            mzcaca(cal)
        } else if (crd < 100) {
            //몬스터 2스킬
            fui(cart)
            anitext("늑대의 울부짖기!", 0.1, 'c', 0.5);
            fui('w.r')
            anitext('"아우울!"', 0.1, 'w', 2);
            cjspd = 5
            br()
            anitext('늑대가 빨라졌다!', 0.1, 'c', 2);

        }
    }
}
const goldwolf = {
    name: '황금늑대',
    art: 'wolf',
    hp: 100,
    spd: 5,
    dmg: 10,
    def: 5,
    hk: "",
    tk1: '"으르릉"',
    tk2: '"깨갱"',

    exp: 100,
    gold: 100,

    atk(crd, cal, cmhp, chp, cdmg, chkc, chk) {
        fui(cart)
        if (crd < 60) {
            //몬스터 기본공격
            anitext("황금늑대의 깨물기!", 0.1, 'c', 1);
            fui('w.q')
            anitext('"아그작"', 0.1, 'w', 2);
            cal = cdmg - p1.zdef
            mzcaca(cal)

        } else if (crd < 90) {
            //몬스터 1스킬
            fui(cart)
            anitext("황금늑대의 할퀴기!", 0.1, 'c', 0.5);
            fui('w.w')
            anitext('"크아앙"', 0.1, 'w', 2);
            cal = (cdmg * 2) - p1.zdef
            mzcaca(cal)
        } else if (crd < 100) {
            //몬스터 2스킬
            fui(cart)
            anitext("늑대의 울부짖기!", 0.1, 'c', 0.5);
            fui('w.r')
            anitext('"아우울!"', 0.1, 'w', 2);
            cjspd = 5
            br()
            anitext('늑대가 빨라졌다!', 0.1, 'c', 2);

        }
    }
}

const bat = {
    name: '흡혈박쥐',
    art: 'bat',
    hp: 50,
    spd: 30,
    dmg: 10,
    def: 0,
    hk: "",
    tk1: '"찍!"',
    tk2: '"찌익!"',
    exp: 1,
    gold: 1,

    atk(crd, cal, cmhp, chp, cdmg, chkc, chk) {
        fui(cart)
        if (crd < 40) {
            //몬스터 기본공격
            anitext("흡혈박쥐의 발톱 할퀴기!", 0.1, 'c', 1);
            fui('w.w')
            anitext('"찍찍!"', 0.1, 'w', 2);
            cal = cdmg - p1.zdef
            mzcaca(cal)

        } else if (crd < 80) {
            //몬스터 1스킬
            fui(cart)
            anitext("흡혈박쥐의 흡혈!", 0.1, 'c', 0.5);
            fui('w.q')
            anitext('"찍찍!"', 0.1, 'w', 2);
            cal = cdmg - p1.zdef
            chh = 1
            mzcaca(cal)
        } else if (crd < 100) {
            //몬스터 2스킬
            fui(cart)
            anitext("흡혈박쥐가 도망쳤다!", 0.1, 'c', 0.5);
            br()
            anitext('(퍼덕퍼덕)', 0.1, 'w', 3);
            cl()
            pturn = 0
            ft = 0
        }
    }
}

const trabbit = {
    name: '대토',
    art: 'trabbit',
    hp: 1000,
    spd: 9999,
    dmg: 9999,
    def: 0,
    hk: "",
    tk1: '"..."',
    tk2: '"끼익!"',
    exp: 999,
    gold: 999,

    atk(crd, cal, cmhp, chp, cdmg, chkc, chk) {
        fui(cart)
        //몬스터 기본공격
        anitext("대토의 공격!", 0.1, 'c', 0.5);
        fui(cart)
        anitext('"..!"', 0.1, 'w', 0.5);
        cal = cdmg - p1.zdef
        mzcaca(cal)
    }
}

function mzcaca(dmg) {
    if (p1.zshi >= 1) {
        p1.zshi--
        fui(cart)
        anitext(p1.name + '용사는 적의 공격을 막아냈다!', 0.1, 'c', 2);
    } else {
        yrd = Math.floor(Math.random() * 100) + 1
        if (yrd <= p1.fhwp) {
            fui(cart)
            anitext(p1.name + '용사는 적의 공격을 회피했다!', 0.1, 'c', 2);
        } else {
            if (dmg < 0) { dmg = 0 }
            p1.zhp -= dmg
            if (p1.zhp < 0) { p1.zhp = 0 }
            fui(cart)
            anitext(p1.name + '용사는 ' + (dmg) + '의 피해를 입었다!', 0.1, 'c', 2);
            if (bansa === 1 && p1.zhp > 0) {
                bansa = 0
                cjhp = dmg
                if (cjhp < 0) { cjhp = 0 }

                fui(cart)
                anitext(cname + '(은)는 반사 피해를 입었다!', 0.1, 'c', 2);
            }
            if (chh === 1 && p1.zhp > 0) {
                chh = 0
                chp += dmg
                if (chp > cmhp) { chp = cmhp }

                fui(cart)
                anitext(cname + '(은)는 체력을 ' + dmg + '회복했다!', 0.1, 'c', 2);
            }
        }
    }

    if (p1.zhp <= 0) {
        fui(cart)
        anitext("크윽...", 0.1, 'w', 2);
        br()
        anitext(p1.name + '용사는 쓰러졌다.', 0.1, 'c', 3);
        cl()
        pturn = 0
        ft = 0
    }
}

// 로비 화면을 출력하는 함수
function displayLobby() {
    console.clear();

    // 타이틀 텍스트
    console.log(
        chalk.cyan(
            figlet.textSync('Isekai like', {
                font: 'ANSI Shadow',
                horizontalLayout: 'default',
                verticalLayout: 'default'
            })
        )
    );

    // 상단 경계선
    const line = chalk.magentaBright('='.repeat(50));
    console.log(chalk.magenta('──────────────────────────────────────────────────────────────────────'));

    // 게임 이름
    console.log(chalk.yellowBright.bold('I-L 게임에 오신것을 환영합니다!'));

    // 설명 텍스트
    console.log(chalk.green('옵션을 선택해주세요.'));
    console.log();

    // 옵션들
    console.log(chalk.blue('1.') + chalk.white(' 새로운 게임 시작'));
    console.log(chalk.blue('2.') + chalk.white(' 업적 확인하기'));
    console.log(chalk.blue('3.') + chalk.white(' 테스팅 메뉴'));
    console.log(chalk.blue('4.') + chalk.white(' 종료'));

    // 하단 경계선
    console.log(chalk.magenta('──────────────────────────────────────────────────────────────────────'));

    // 하단 설명
    console.log(chalk.gray('1-4 사이의 수를 입력한 뒤 엔터를 누르세요.'));
}

// 유저 입력을 받아 처리하는 함수
function handleUserInput() {
    var bachoice = ['새로운 게임 시작', '업적 확인하기', '테스팅 메뉴', ' 종료',]
    const choice = readlineSync.question(' > ');

    switch (choice) {
        case '1':
            console.log(chalk.green('게임을 시작합니다.'));
            fgame();
            // igame();
            break;
        case '2':
            console.log(chalk.yellow('구현 준비중입니다.. 게임을 시작하세요'));
            // 업적 확인하기 로직을 구현
            handleUserInput();
            break;
        case '3':
            console.log(chalk.blue('테스팅 돌입'));
            sleep(2)
            cl()
            anitext('(고르는 무기에 따라 직업이 결정됩니다.)', 0.1, 'b', 1);
            br()
            anitext('(1.검 2.방패 3.지팡이 4.단도 5.활)', 0.1, 'b', 1);
            br()
            for (var i = 0; i === 0;) {
                let choice2 = readlineSync.question(' > ');
                wepo = choice2;
                switch (choice2) {
                    case '1':
                        anitext('검을 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                        p1.class = 'warrior'
                        p1.wepon = "ww1"
                        i++
                        break;
                    case '2':
                        anitext('방패를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                        p1.class = 'defender'
                        p1.wepon = "wd1"
                        i++
                        break;
                    case '3':
                        anitext('지팡이를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                        p1.class = 'magiccaster'
                        p1.wepon = "wm1"
                        i++
                        break;
                    case '4':
                        anitext('단도를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                        p1.class = 'rogue'
                        p1.wepon = "wr1"
                        i++
                        break;
                    case '5':
                        anitext('활을 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                        p1.class = 'archer'
                        p1.wepon = "wa1"
                        i++
                        break;
                    case '1324':
                        anitext('당신.. 개발자군요?', 0.1, 'c', 1);
                        p1.class = 'tenster'
                        p1.hat = "h1"
                        p1.armor = "a1"
                        p1.shoes = "s1"
                        p1.gloves = "g1"
                        p1.pendant = "p1"
                        p1.wepon = "w1"
                        i++
                        break;
                    default:
                        anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);
                        cl()
                        console.log(chalk.blue('(고르는 무기에 따라 직업이 결정됩니다.)'));
                        console.log(chalk.blue('(1.검 2.방패 3.지팡이 4.단도 5.활)'));
                }
            }

            cl()
            anitext('장비를 설정합니다.', 0.1, 'b', 1);
            br()
            anitext('(1.기본 2.사냥꾼 세트(신궁 장비) ...추가 예정)', 0.1, 'b', 1);
            br()

            for (i = 0; i === 0;) {
                let choice2 = readlineSync.question(' > ');
                wepo = choice2;
                switch (choice2) {
                    case '1':
                        i++
                        break;
                    case '2':
                        anitext('사냥꾼 세트를 장비합니다.', 0.1, 'c', 1);
                        p1.hat = "h4"
                        p1.armor = "a4"
                        p1.shoes = "s4"
                        p1.gloves = "g4"
                        p1.pendant = "p4"
                        p1.wepon = "wa4"
                        i++
                        break;
                    case '1324':
                        anitext('테스터 세트를 장비합니다.', 0.1, 'c', 1);
                        p1.hat = "h1"
                        p1.armor = "a1"
                        p1.shoes = "s1"
                        p1.gloves = "g1"
                        p1.pendant = "p1"
                        p1.wepon = "w1"
                        i++
                        break;
                    default:
                        anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);
                        cl()
                        console.log(chalk.blue('장비를 설정합니다.'));
                        console.log(chalk.blue('(1.기본 2.사냥꾼 세트(신궁 장비) ...추가 예정)'));
                }
            }

            cl()
            anitext('전투 몬스터를 정합니다.', 0.1, 'b', 1);
            br()
            anitext('(1.늑대 2.흡혈박쥐 3.대토 4.황금늑대)', 0.1, 'b', 1);
            br()

            for (i = 0; i === 0;) {
                let choice2 = readlineSync.question(' > ');
                wepo = choice2;
                switch (choice2) {
                    case '1':
                        anitext('늑대와 전투를 합니다.', 0.1, 'c', 1);
                        tsmon = 'wolf'
                        i++
                        break;
                    case '2':
                        anitext('흡혈박쥐와 전투를 합니다.', 0.1, 'c', 1);
                        tsmon = 'bat'
                        i++
                        break;
                    case '3':
                        anitext('대토와 전투를 합니다.', 0.1, 'c', 1);
                        tsmon = 'trabbit'
                        i++
                        break;
                    case '4':
                        anitext('황금늑대와 전투를 합니다.', 0.1, 'c', 1);
                        tsmon = 'goldwolf'
                        i++
                        break;
                    default:
                        anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);
                        cl()
                        console.log(chalk.blue('전투 몬스터를 정합니다.'));
                        console.log(chalk.blue('(1.늑대 2.흡혈박쥐 3.대토 4.황금늑대)'));
                }
            }

            cl()
            anitext('전투 몬스터의 배수를 정합니다.', 0.1, 'b', 1);
            br()
            anitext('1~5 입력 (1이 기본)', 0.1, 'b', 1);
            br()

            for (i = 0; i === 0;) {
                let choice2 = readlineSync.question(' > ');
                wepo = choice2;
                switch (choice2) {
                    case '1':
                        fight(tsmon, 1)
                        i++
                        break;
                    case '2':
                        fight(tsmon, 2)
                        i++
                        break;
                    case '3':
                        fight(tsmon, 3)
                        i++
                        break;
                    case '4':
                        fight(tsmon, 4)
                        i++
                        break;
                    case '5':
                        fight(tsmon, 5)
                        i++
                        break;
                    default:
                        anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);
                        cl()
                        console.log(chalk.blue('전투 몬스터의 배수를 정합니다.'));
                        console.log(chalk.blue('1~5 입력 (1이 기본)'));
                }
            }


            // fcl()
            // p1.class = 'rogue'
            // // p1.class = 'magiccaster'
            // // p1.class = 'archer'
            // p1.hat = "h4"
            // p1.armor = "a4"
            // p1.shoes = "s4"
            // p1.gloves = "g4"
            // p1.pendant = "p4"
            // // p1.wepon = "wa4"
            // p1.wepon = "wr1"

            // p1.hat = "h1"
            // p1.armor = "a1"
            // p1.shoes = "s1"
            // p1.gloves = "g1"
            // p1.pendant = "p1"
            // p1.wepon = "w1"
            checkitem()
            chokihwa()
            // fight(trabbit, 1)
            fight(wolf, 1)
            // fight(bat, 1)
            igame()
            sleep(10)
            break;
        case '4':
            console.log(chalk.red('게임을 종료합니다.'));
            // 게임 종료 로직을 구현
            process.exit(0); // 게임 종료
            break;
        default:
            console.log(chalk.red('올바른 선택을 하세요.'));
            handleUserInput(); // 유효하지 않은 입력일 경우 다시 입력 받음
    }
}

// 게임 시작 함수
function start() {
    displayLobby();
    handleUserInput();
}

//기다리기
function sleep(sec) {
    let start = Date.now(), now = start;
    while (now - start < sec * 1000) {
        now = Date.now();
    }
}

//그림 출력
function aniprt(char) {

    if (char === '복사용') {
        console.log(chalk.blueBright(""))
    }

    //캐릭터
    if (char === '1code') {
        console.log(chalk.blue("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⣀⠄⠄⠄⠄⠄⣄⣀⢀\n⠀⠀⠀⠀⠀⠀⠀⠀⡠⠔⠘⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠢⢄⡀\n⠀⠀⠀⠀⠀⠀⡔⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡀\n⠀⠀⠀⠀⢀⠎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠱⡀\n⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱\n⠀⠀⠀⡸⠀⠀⠀⠀⠀⢀⣠⣴⣾⣿⣿⣿⣿⣿⣿⣷⣶⣤⣀⠀⠀⠀⠀⠀⠈⡆\n⠀⠀⣴⡇⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⣿⣦\n⠀⣾⣿⡇⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⢿⣿⣧\n⠨⣿⣿⡇⠀⠀⣾⣿⣿⡟⠋⠉⠙⠻⣿⣿⣿⣿⡟⠋⠉⠉⠛⣿⣿⣿⡆⠀⠀⣿⣿⣿\n⠀⢻⣿⡇⠀⠀⣿⣿⣿⡀⠀⠀⠀⠀⢸⣿⣿⣟⠀⠀⠀⠀⢀⣸⣿⣿⡇⠀⠀⣿⣿⠃\n⠀⠀⠙⢇⠀⠀⢿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⡟\n⠀⠀⠀⠈⢆⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⢀⠜\n⠀⠀⠀⠀⠀⠱⢄⠀⠉⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⠋⠁⢀⡰⠊\n⠀⠀⠀⠀⠀⠀⠀⠉⠒⠤⢄⣀⡀⠁⠉⠉⠉⠉⠈⡀⣀⣀⠠⠔⠊⠁\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠈⠁⠉⠉⠁⠁\n\n"))
    }
    if (char === 'code') {
        console.log(chalk.cyanBright("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣀⣀⣀\n⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣤⡀\n⠀⠀⠀⠀⠀⢀⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀\n⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆\n⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄\n⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⡿⠟⠋⠉⠉⠉⠉⠉⠉⠛⠻⢿⣿⣿⣿⣿⣿⣿⣧\n⠀⠀⡴⢹⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⣿⣿⣿⣿⡏⠳⡀\n⠀⡞⠀⢸⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⡇⠀⢹⡀\n⢸⡇⠀⢸⣿⣿⠇⠀⠀⣠⣶⣶⣦⣄⠀⠀⠀⢀⣤⣶⣶⣶⣄⠀⠀⢹⣿⣿⡇⠀⢸⡇\n⠀⢧⡀⢸⣿⣿⠀⠀⠘⢿⣿⣿⣿⣿⠇⠀⠀⢾⣿⣿⣿⣿⠿⠀⠀⢸⣿⣿⡇⢀⡼⠁\n⠀⠀⠙⣼⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣷⠋\n⠀⠀⠀⠈⢿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⡿⠃\n⠀⠀⠀⠀⠀⠙⢿⣿⣿⣦⣤⣀⣀⡀⠀⠀⠀⠀⣀⣀⣠⣤⣶⣿⣿⡿⠟\n⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠟⠛⠉\n\n\n"))
    }

    if (char === 'mio') {
        console.log(chalk.white("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⡐⠀⢀⠠⠀⢀⡐⠀⠀⠀⠀⠄⢀\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠠⠀⠐⠀⠀⠀⢀⠤⠀⡀⠉⠀⠀⢄⠀⠄⠐⢀\n⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠁⠂⠀⢁⠆⠁⢀⠄⢁⡄⢀⠀⠀⢠⠀⠈⡁⠄⠃⠠⠐⣀⠀⠀⠀⠀⠈\n⠀⠀⠀⠀⠀⠀⠀⠡⠀⠀⠀⠀⠀⡐⡎⠉⠉⠚⠀⡼⢠⠃⠀⠀⢸⠀⠀⠘⡀⡁⠀⠀⠀⠁⢆⠀⠀⠀⠁\n⠀⠀⠀⠀⢀⠀⠀⠄⠥⣀⢀⡁⠆⠀⣤⢐⠊⠀⠈⡤⢋⠀⠀⠀⠸⡆⢁⠀⠐⠐⢂⠀⠀⠀⢀⠊⠀⢀⠂\n⠀⠀⠀⠀⠀⠀⡀⠘⠡⠄⠣⢄⡈⠖⢡⠊⠄⠀⡞⠀⠇⠀⠀⢀⠇⠸⡘⡆⠀⢀⠂⢰⣀⠀⠄⠈⠠⠃⠀⠀⠀⠄\n⠀⠀⠀⠀⠀⠀⢁⠀⠀⠈⠅⡘⠁⢸⡃⠄⢰⠘⡀⡈⠄⠀⠄⡊⠀⠄⡑⢌⡀⢠⡑⠂⠀⠨⠐⠃⢢⠈⠀⢀⠁\n⠀⠀⠀⠀⠈⠀⠀⢀⠁⠐⡀⢀⠴⠑⡤⡑⢿⡿⣿⡗⠠⢈⠌⠀⢺⡿⠿⣮⢷⣠⠇⠀⠀⠀⠀⡜⢤⣤⡐⠀⡀\n⠀⠀⠀⠒⢂⠲⠒⢲⠀⠈⢐⡥⢲⣝⠂⡁⠩⠀⡜⠀⡡⠁⠀⠀⠀⠢⠄⠤⢘⠼⢐⠀⠀⣀⠔⣣⠀⢆⡉⠓⠢⡀\n⠀⠀⠀⡐⢄⡒⢕⡷⢡⣰⡇⠾⣹⢸⢡⡇⢀⠔⢀⠆⠀⠀⠀⠀⠀⠀⠀⢀⠂⡟⢨⡧⢚⠀⢰⣿⡅⡈⠧⡓⠢⠱⢈⠂\n⠈⠐⣀⠤⢠⠲⡋⢐⡥⣿⢸⢹⠿⠨⢼⢖⡡⠐⠁⠀⠠⠄⠠⢄⠀⠀⠀⢀⡼⠀⡘⡀⡄⡠⠃⢺⣿⣦⡀⢪⣑⠒⠠⠠\n⠀⠁⡠⠈⣔⣍⣴⡿⣾⡯⢸⡿⠐⡴⢺⡿⣿⣦⣀⠀⠈⠢⠄⠊⠀⢀⣰⣾⠇⡰⡁⣤⣵⠂⠱⣸⡦⢳⡄⠁⠦\n⠀⠂⢠⢞⡟⡣⠕⣾⣿⠷⡿⠃⠼⢇⠀⢻⠛⡿⣿⣷⠂⠤⠠⠔⠈⣿⢙⠏⡰⢃⠸⣿⣿⣄⠀⣅⢳⠀⠮⠁⢠\n⢀⠤⡥⠀⠔⣡⣿⠿⢋⠔⢠⠇⢨⡌⣆⠄⠣⠷⠼⠞⠀⠀⠀⠀⠀⢨⠇⣄⠁⠎⡘⠜⢮⠻⡶⣿⣖⢠⡐⠄⠀⠂\n⠊⡑⡒⠉⠘⠻⢗⠏⡼⠐⠁⠈⢆⠀⠈⠠⠑⣀⠆⣱⠠⢀⠀⠠⠤⣆⠈⡍⡼⠐⠁⠉⠈⠑⠱⢌⡻⣧⣵⣀⠀⢀⠄⠊\n⢀⠀⠃⠀⠀⠀⠀⠡⡀⠀⠀⠀⠈⠀⠄⠀⠠⠈⠂⡀⠁⠆⡠⠔⠉⠄⢉⠠⠐⠀⠀⠀⠀⠀⠀⠈⠱⠊⠁⣮⠃\n⢄⣉⣀⠀⠀⣀⠃⠀⠐⠀⠀⠀⠠⢀⠀⠄⠀⡁⢀⠂⠀⣠⠃⠀⠀⠁⢤⠂⠀⠀⠀⠠⠀⠀⢀⡁⠀⠀⠀⠇⠀⠀⡀\n⢀⡀⠠⠉⠄⠈⠁⠂⠀⢃⠌⢦⠌⠀⠀⢸⡰⠁⢠⢣⡒⣲⡟⢰⠄⢆⠂⠀⠂⠀⠀⠡⡤⠂⠀⠠⢀⠄⠂⠁⠀⠙⠄⢈\n⣀⠀⠀⠀⠀⠀⠀⠸⠐⠃⠀⠈⠀⠀⢀⠟⠀⠐⢁⠲⠸⢖⠺⠭⠓⡌⠢⡀⠀⠀⡀⠀⠃⠀⡀⣥⠃⠄\n⠁⠈⡡⠐⠀⠠⠂⠀⢸⡀⠀⠀⣌⢊⣡⠀⠀⠄⠁⠀⠀⠈⠄⠀⠀⠈⡁⠀⢂⠔⠈⡌⣁⠀⢉⣋⣀⣄⣃⠤⢐⠂⠚⢈\n⢄⠚⠀⠀⠈⠀⠀⣀⢆⡜⠦⠀⠄⠀⠀⠈⠁⠒⠄⠀⠀⠀⠀⠸⡀⠇⣀⠱⠈⠀⢡⢃⠉⠁⠂⠀⡂⠀⠉⡒⠄⢆⡀\n"))
    }
    //몬스터 - 도트아트 가로 32자
    if (char === 'wolf') {
        console.log(chalk.blueBright("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⢀⡀\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠗⣦⣦⡤⣖⢻⡏\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣼⣫⢾⣿⣿⣾⣿⣤\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⢙⡿⢟⠿⣿⣷⢿⡿⣿⡀\n⠀⠀⠀⠀⠀⠀⠀⢀⣴⣖⣶⣿⣗⡄⡿⢇⣸⣀⡈⠉⣜⡊⠉⣁⣼⠄\n⠀⠀⠀⠀⠀⠀⣴⣿⣿⣾⣿⢿⡿⢸⣇⡈⣾⣦⡀⠢⣿⣧⣗⣵⡏\n⠀⠀⠀⠀⠀⠠⣿⢿⣿⣿⣣⡉⠋⠸⡿⢿⣭⣿⣿⣷⠍⣝⣿⠟\n⠀⠀⠀⠀⠀⡌⢯⣸⣿⠻⣷⣧⠆⠀⢇⠘⠻⣾⡭⣿⣿⣿⠟\n⠀⠀⠀⠀⠀⠂⢸⣾⠏⣄⡉⢟⡇⠀⢸⡆⢀⢈⣽⣿⣿⡏\n⠀⠀⠀⠀⠀⣷⣮⢛⠀⣿⣿⣾⣄⣼⠀⣷⣿⡿⣿⣿⣿⠁\n⠀⠀⠀⠀⢠⣽⣿⡜⣸⣿⣿⣿⣿⡟⠈⣿⠁⠀⢸⣿⢻\n⠀⠀⠀⠀⢸⢾⣿⡇⣿⣿⡟⣿⡟⠀⠀⢻⡄⠀⠈⡿⡄\n⠀⠀⠀⠀⠸⣿⣿⡇⣿⣿⢼⣿⠀⠀⠀⢼⣇⠀⠀⠏⡇\n⠀⠀⠀⠀⠀⠻⠿⠁⡿⠁⠈⣿⠀⠀⠀⠈⡙⠀⠀⠈⠈\n⠀⠀⠀⠀⠀⠀⠀⠆⠶⠄⠀⠸⠶⠤⠤⢠⣡⡄⠀⠘⣤⡤⣀\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠁⠀⠀⠈⠉⠉\n"))
    }
    if (char === 'w.q') {
        console.log(chalk.blueBright("⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀\n⣿⣿⠿⠟⠛⠀⠀⠀⠀⠀⠀⣠⠔⠋⠉⠉⣉⠉⠉⠉⠀⠀⠙⢦⡀\n⣿⡇⠀⠀⠀⠀⠀⠀⣀⠔⢪⣴⣿⣦⡀⢰⣿⣷⡀⣴⣦⣶⣦⠀⠑⢄\n⠿⣄⣀⣠⠤⠖⠒⠉⣤⣄⣿⣿⣿⣿⣿⡄⠙⢿⠇⠻⠋⠙⠟⠀⠀⠀⠳⡄\n⠀⢸⠀⠀⠀⣠⢺⣿⠍⠿⠘⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠲⡀\n⢧⡘⡇⢠⣾⣿⡜⣟⣀⣴⠾⣿⠻⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣽\n⠀⠹⣇⣿⣿⣿⣷⣿⢻⠏⠀⠈⠀⠈⠙⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⡠⠞⠉⠀⡞\n⠀⠀⠀⠀⠀⢻⣿⣿⡀⠀⠀⠀⠀⠀⠀⠰⠈⠉⠛⠛⠷⠄⠀⢀⡞⠀⢤⣀⣀⡇\n⠀⠀⠀⠀⠀⠈⢿⣿⣷⡀⠀⠀⠀⠀⠀⠀⢣⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠻⢿\n⠀⠀⠀⠀⠀⠀⠈⠻⣿⣷⣄⠀⠀⠀⠀⠀⠈⡆⠀⠀⠀⠀⠀⢺⠀⠀⢳⣦⣼\n⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣦⣀⠀⠀⠀⠀⢹⠀⠀⢼⣿⣦⣸⠀⠀⠈⠻⢿\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠓⠀⠀⠀⠈⡇⠐⢶⣬⡙⣿⣦⠐⣾⣶⣾\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⠀⣀⣙⣃⢹⣿⣷⣦⣉⢻\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣦⡀⠀⠀⢸⠀⠙⠛⠛⠀⢻⣿⣿⣿⣿\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣶⣼⣤⣤⣤⣤⡀⠀⣙⡿⣿⡏\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣿⣿⣿⠳⣶⣿⠇\n"))
    }
    if (char === 'w.w') {
        console.log(chalk.blueBright("⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⣴⣿⣿⠏⣠⣾⣿⠏\n⠀⠀⠀⠀⢀⣴⡾⠋⢀⣼⣿⣿⠃⣴⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⠄\n⠀⠀⠀⢠⣿⣿⠁⢠⣾⣿⣿⣇⣾⣿⣿⡟⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⠟⠁\n⠀⠀⢰⣿⣿⡏⠀⣾⣿⠏⣾⣿⣿⣿⣿⠁⠀⠀⠀⢀⣴⣿⣿⣿⡟⠁\n⠀⠀⣼⣿⡿⢧⠀⢸⡇⠘⣿⣿⣿⡟⡏⠀⠀⢠⣶⣿⣿⣿⣿⠋\n⠀⠀⠿⣿⠇⠘⣄⢸⡇⠀⣿⣿⠏⢸⠃⠀⠀⢸⣿⣿⣿⣿⠃\n⠀⠀⠀⠈⢧⠀⠈⠙⠁⠀⡿⠃⠀⣼⠀⠀⣠⣾⣿⣿⣿⠇\n⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⢾⣿⣿⠟⠁⣸\n⠀⠀⠀⠀⠈⠣⡀⠀⠀⠀⠀⠀⠀⠸⡄⢸⠋⠀⠀⢰⠃⠀⠀⠀⠀⠀⠀⠀⠀⣴\n⠀⠀⠀⠀⠀⠀⠙⢆⠀⠀⠀⠀⠀⠀⠙⠾⠀⠀⠀⠘⣆⠀⠀⠀⠀⠀⠀⠀⣼⣿\n⠀⠀⠀⠀⠀⠀⠀⠈⠳⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡄⠀⠀⠀⠀⠀⣼⣿⣿\n⠀⠀⠀⠀⠀⠀⠀⢠⡞⠁⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⢸⠁⠀⠀⠀⢀⣼⣿⣿⣿\n⠀⠀⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⢟⡀⠀⣠⠔⣻⣿⣿⣿⡟\n⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠉⠉⠀⢠⣿⣿⠿⠿⠇\n⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⠀⠀⣸⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⢀⣿⣿⡿⠆\n⠀⠀⠀⠀⠀⠀⠀⣇⠀⠀⠀⠀⡟⠀⠀⠀⡇⠀⠀⠀⢠⠦⢤⡼⠿⠋\n"))
    }
    if (char === 'w.r') {
        console.log(chalk.blueBright("⠀⠀⠀⠀⢀\n⠀⠀⠀⢐⠋⠱⣄\n⠀⠀⡏⠚⠀⠀⢇⠗⣢\n⠀⠀⠈⡆⠀⠀⡸⢌⡐⠳⡄\n⠀⠀⠀⢄⢠⠞⡡⠆⢭⣂⡙⢲⡄\n⠀⠀⠀⢨⠇⡜⣠⠙⠤⡡⡉⢧\n⠀⠀⠀⢼⠘⡰⠄⣍⠒⣡⠱⣈⠳⡀\n⠀⠀⠀⢸⠱⡐⡩⢄⠓⣄⠣⠔⡡⢳⡀\n⠀⠀⠀⠸⢄⠣⡑⡌⣊⠤⠓⣌⢑⠢⡱⢄\n⠀⠀⠀⠈⣆⠓⡌⡔⢢⠡⢋⠔⠬⡑⡔⢩⡑⢆\n⠀⠀⠀⠀⠸⣘⠰⢌⠢⢍⢢⢉⠖⡡⠜⢢⠘⡌⢓⣄\n⠀⠀⠀⠀⠀⠑⣎⠢⢍⠒⡌⠢⢎⠰⡉⠆⡍⠔⠣⢌⠳⣄\n⠀⠀⠀⠀⠀⠀⢸⡐⢎⡱⢌⡱⢌⠱⡨⣑⢌⠩⠚⣄⠣⢌⢣⡀\n⠀⠀⠀⠀⠀⠀⠰⡡⢒⡸⢆⠔⣊⠱⠰⣸⠌⡜⢡⠢⣑⢊⠤⢓⡄\n⠀⠀⠀⠀⠀⠀⢰⠡⢃⡆⠈⠳⡠⢍⠱⡠⠳⣌⠢⣑⠢⢌⡒⢭⡘⢦⣀⣀⡠⠔⡲⢑\n⠀⠀⠀⠀⠀⠀⢸⠱⢨⠄⠀⠀⠙⢦⢑⢂⡓⢌⠳⣄⠣⠒⡌⠶⡁⠖⡠⢆⠱⡘⢄⠣\n"))
    }

    if (char === 'bat') {
        console.log(chalk.blueBright("\n\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣄⣠⡄\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠤⠖⠋⠉⠁⠀⠀⡇\n⢖⠒⠒⠒⠒⠤⠤⣄⣀⡀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⡷⠾⠭⠤⠦⠴⠤⠦⠴⢤⡼⠁\n⠘⣆⣀⣀⣠⠤⠤⠤⠤⠙⢛⠧⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠜⠁⠀⢳⡀⠀⠀⠀⠀⣠⠞⠁\n⠀⠈⠑⠦⣀⠀⠀⠀⠀⠀⡞⠀⠀⠉⠲⢄⡀⠀⠀⢀⣾⣀⣄⣳⡄⠀⢀⡤⢞⣁⠀⠀⠀⠀⢳⡀⠀⢠⠞⠁\n⠀⠀⠀⠀⠈⠙⢆⠀⠀⣸⠁⠀⠀⣀⣠⠴⠛⠒⢤⣠⣿⣽⣻⣽⣧⠖⠉⠀⠀⠈⠙⠒⠦⣄⣀⢣⢠⠇\n⠀⠀⠀⠀⠀⠀⠈⠳⣄⢇⡠⠔⠚⠁⠀⠀⠀⠀⠀⢼⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⢀⡴⠚⠛⠋\n⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠋⠲⣄⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⣠⠜⠁\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠢⣄⠀⢀⣾⢿⣿⣿⣿⣿⠿⣦⡀⣠⠞⠁\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢷⡿⢡⣌⠻⣿⣿⠏⣠⠬⢻⡧\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠉⠘⠛⠉⠀⠀⠈\n\n\n\n"))
    }


    if (char === 'trabbit') {
        console.log(chalk.white("\n\n\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⢀⡀\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠀⠀⠀⢸⣿⡄\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⡆⠀⠀⡌⣿⣿\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⡇⠈⠒⠒⠀⢻⣿\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡝⠀⠀⢼⡷⠀⠀⠹⡀\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⢻⢠⣷⠀⠀⠀⠀⣼⡇⢿⢄\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢏⠆⠀⠁⠀⢨⢏⠀⠈⠀⠈⡎⣆\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡈⠧⣀⣀⡀⠀⢀⣀⣀⠀⠴⠃⢸\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠓⠀⠀⠀⠈⠁⠁⠉⠀⠀⠀⢀⢫⠇\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣄⠑⠦⢄⠀⠠⠠⠀⢀⡀⠔⣋⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠘⠡⠇⠂⠒⠘⠿⠛⠉\n\n\n"))
    }
}

//줄바꿈
function br() { console.log("") };

//청소
function cl() { console.clear() };

//텍스트타이핑효과
function anitext(text, speed, color, delay) {
    if (color === 'w') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.white(text.charAt(i)));
            sleep(speed);
        }
    } else if (color === 'b') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.blue(text.charAt(i)));
            sleep(speed);
        }
    } else if (color === 'y') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.yellow(text.charAt(i)));
            sleep(speed);
        }
    } else if (color === 'g') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.green(text.charAt(i)));
            sleep(speed);
        }
    } else if (color === 'c') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.cyan(text.charAt(i)));
            sleep(speed);
        }
    } else if (color === 'm') {
        for (let i = 0; i < text.length; i++) {
            process.stdout.write(chalk.magenta(text.charAt(i)));
            sleep(speed);
        }
    }
    sleep(delay);
}

//플레이어초기화
function chokihwa() {
    p1.zshi = 0

    p1.hp = p1.fhp
    p1.mp = p1.fmp
    p1.dmg = p1.fdmg
    p1.def = p1.fdef
    p1.spd = p1.fspd

    p1.zhp = p1.fhp
    p1.zmp = p1.fmp
    p1.zdmg = p1.fdmg
    p1.zdef = p1.fdef
    p1.zspd = p1.fspd
}

//청소+ui띄우기
function fcl() {
    console.clear()
    console.log(chalk.yellowBright("────────────────────────────────────────────────────────────"))
    process.stdout.write(chalk.cyanBright("용사 " + p1.name));

    //상태이상 거는 몬스터가 아직 없음 ㅋㅋ
    // if (p1.zhk === 'silence') { process.stdout.write(chalk.white("[침묵]")); }
    // if (p1.zhk === 'burn') { process.stdout.write(chalk.red("[화상]")); }
    // if (p1.zhk === 'moist') { process.stdout.write(chalk.blueBright("[수분]")); }
    // if (p1.zhk === 'shock') { process.stdout.write(chalk.yellowBright("[감전]")); }
    // if (p1.zhk === 'poison') { process.stdout.write(chalk.magentaBright("[독]")); }
    // if (p1.zhk === 'neutralize') { process.stdout.write(chalk.gray("[무력화]")); }
    process.stdout.write(chalk.redBright("        HP : " + p1.zhp + " / " + p1.fhp));
    process.stdout.write(chalk.blueBright("        MP : " + p1.zmp + " / " + p1.fmp));
    console.log(chalk.yellowBright("\n────────────────────────────────────────────────────────────"))
}
function fui(ccart) {
    fcl()
    process.stdout.write(chalk.cyanBright("몬스터 " + cname + " "));

    //상태이상 띄우기
    if (chk === 'silence') { process.stdout.write(chalk.white("[침묵]")); }
    if (chk === 'burn') { process.stdout.write(chalk.red("[작열]")); }
    if (chk === 'moist') { process.stdout.write(chalk.blueBright("[수분]")); }
    if (chk === 'shock') { process.stdout.write(chalk.yellowBright("[감전]")); }
    if (chk === 'poison') { process.stdout.write(chalk.magentaBright("[중독]")); }
    if (chk === 'neutralize') { process.stdout.write(chalk.gray("[무력화]")); }
    process.stdout.write(chalk.redBright("        HP : " + chp + " / " + cmhp));
    br()
    console.log(chalk.yellowBright("────────────────────────────────────────────────────────────"))
    aniprt(ccart)
    console.log(chalk.yellowBright("────────────────────────────────────────────────────────────"))
}

//전투 전역 변수
var cjname = ""
var cjmhp = 0
var cjhp = 0
var cjdef = 0
var cjdmg = 0
var cjspd = 0
var cjhk = ""
var chwp = 0
var cjj = 0

var cname = ""
var cmhp = 0
var chp = cmhp
var cdef = 0
var cdmg = 0
var cspd = 0
var chk = ""
var cart = ""
var cexp = 0
var cgold = 0

var cjart = 0
var cjtk1 = 0
var cjtk2 = 0
var bansa = 0
var ft = 1
var chh = 0
var yrd = 0
var zip = 0
var ygc = 0

var pturn = 0
var ptt = 0

var ilvup

//전투 부분
function fight(monster, baesu) {

    cname = monster.name
    cmhp = baesu * monster.hp
    chp = cmhp
    cdef = baesu * monster.def
    cdmg = baesu * monster.dmg
    cspd = monster.spd
    chk = monster.hk
    cart = monster.art
    cexp = monster.exp * baesu
    cgold = monster.gold * baesu

    var ctk1 = monster.tk1
    var ctk2 = monster.tk2

    cjmhp = cmhp
    cjhp = 0
    cjdef = 0
    cjdmg = 0
    cjspd = 0
    cjhk = chk

    var chkc = 0
    var cok = 1
    var cal = 0


    var crd = 0
    yrd = 0
    zip = 0
    var psk = 0
    var cacal = 0
    var turn = 0
    pturn = 0
    var mturn = 0
    var fturn = 0
    ft = 1

    //전투중에 조건부로 발동하는 장비전용 변수

    var jbp = 0


    //적에게 가하는 데미지 계산 부분
    function caca() {

        if (chwp === 1) {
            chwp = 0
            fui(cart)
            anitext(cname + '(은)는 공격을 피했다!', 0.1, 'c', 2);
        } else {
            br()
            yrd = Math.floor(Math.random() * 100) + 1
            if (yrd <= 10 && p1.gloves === 'g1') {
                cal = cacal * 2
                anitext("텐스터 장갑의 크리티컬!", 0.1, 'c', 0.5);
            } else {
                cal = cacal
            }
            if (chk === 'moist') {
                cal = cal * 1.2
            }
            cal = Math.round(cal)
            cal -= cdef
            if (cal < 0) { cal = 0 }
            chp -= cal
            if (chp < 0) { chp = 0 }
            fui(cart)

            anitext(cname + '(은)는 ' + cal + "의 데미지를 입었다!", 0.1, 'c', 2);
            cjj = 1
        }
    }
    function pturnend() {
        cjj = 0
        turn++
        pturn = 0
    }

    //적이 죽으면 끝나는 반복문---------------------------------------------------
    while (ft === 1) {

        //몬스터 첫 조우
        while (turn === 0) {
            fui(cart)
            anitext("야생의 " + cname + "(이)가 출현했다!", 0.1, 'c', 0.5);
            br()
            anitext(ctk1, 0.1, 'w', 4);
            br()
            anitext("내 스탯 HP:" + p1.zhp + "/MP:" + p1.zmp + "/DMG:" + p1.zdmg + "/DEF:" + p1.zdef + "/SPD:" + p1.zspd, 0.1, 'c', 2);
            turn++
        }

        //스피드 조정 관련 장비


        if (p1.shoes === 's1' && p1.zhp < chp) {
            if (jbp === 0) {
                p1.zspd += 5
                jbp = 1
            }
        } else if (jbp === 1) {
            p1.zspd -= 5
            jbp = 0
        }

        //스피드 빠르면 선공
        if (p1.zsj === 1) {
            pturn = 1
            ptt = 1
            fturn = 1
        } else {
            if (fturn === 0 && (cspd + cjspd) <= p1.zspd) {
                pturn = 1
                ptt = 1
                fturn = 1
            } else {
                mturn = 1
                fturn = 2
            }
        }


        //몬스터 턴
        while (mturn === 1) {
            cal = 0
            if (fturn === 2) {
                fturn = 0
                ptt = 1
                pturn = 1
            }
            fui(cart)
            //선 상태이상 효과
            if (chk === 'burn') {
                chp -= Math.round(p1.fdmg * 0.1)
                fui(cart)
                anitext(cname + "(은)는 불타고 있다!", 0.1, 'c', 2);
            }
            if (chk === 'moist') {

                anitext(cname + "(은)는 젖어있다!", 0.1, 'c', 2);
            }
            if (chk === 'shock') {
                anitext(cname + "(은)는 감전되어 공격 할 수 없다!", 0.1, 'c', 2);
                cok = 0
            }
            if (chk === 'poison') {
                chp -= Math.round(cmhp * 0.1)
                fui(cart)
                anitext(cname + "(은)는 중독 데미지를 입었다!", 0.1, 'c', 2);
            }
            if (chk === 'neutralize') {
                anitext(cname + "(은)는 무력화 상태다!", 0.1, 'c', 2);
                cok = 0
            }

            if (chp <= 0) {
                chp = 0
                cok = 0
                mturn = 0
                fui(cart)
                anitext(ctk2, 0.1, 'w', 2);
                br()
                anitext(cname + '(을)를 물리쳤다!', 0.1, 'c', 3);
                cl()
                ft = 0
            }


            //공격랜덤
            if (cok === 1) {
                crd = Math.floor(Math.random() * 100) + 1
                if (chk === 'silence') {
                    anitext(cname + "(은)는 스킬을 까먹었다!", 0.1, 'c', 2);
                    crd = 1
                }
                monster.atk(crd, cal, cmhp, chp, cdmg, chkc, chk)
                if (chkc >= 1) {
                    chkc -= 1
                }
                if (chkc === 0) {
                    chk = ""
                }
                // chp -= cjhp
                // cjhp = 0
                mturn = 0
            } else {
                if (chkc >= 1) {
                    chkc -= 1
                }
                if (chkc === 0) {
                    chk = ""
                }

                cok = 1
                mturn = 0
            }
        }

        //플레이어 턴
        while (pturn === 1) {
            cal = 0
            if (fturn === 1) {
                fturn = 0
                mturn = 1
            }

            while (ptt === 1) {
                ptt = 0
                cjj = 0
                ygc = 0
                if (zip >= 1) { zip-- }
                p1.zmp += p1.mpzen * p1.xmpzen
                if (p1.zmp >= p1.fmp) { p1.zmp = p1.fmp }
                p1.zhp += p1.hpzen * p1.xhpzen
                if (p1.zhp >= p1.fhp) { p1.zhp = p1.fhp }
            }

            fui(cart)
            console.log(chalk.cyan("1.기본공격 2.스킬 3.인벤토리 4.도망"))
            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
            const fchoice = readlineSync.question(' > ');
            switch (fchoice) {
                case '1':
                    //기본공격
                    fui(cart)
                    if (p1.class === 'warrior') {
                        anitext(p1.name + '용사의 검 휘두르기!', 0.1, 'c', 2);
                        cacal = p1.zdmg
                    }
                    if (p1.class === 'defender') {
                        anitext(p1.name + '용사의 방패공격!', 0.1, 'c', 2);
                        cacal = p1.zdef
                    }
                    if (p1.class === 'magiccaster') {
                        anitext(p1.name + '용사의 지팡이 공격!', 0.1, 'c', 1);
                        anitext('(물리)', 0.1, 'c', 1);
                        cacal = p1.zdmg * 0.5
                    }
                    if (p1.class === 'rogue') {
                        anitext(p1.name + '용사의 암살!', 0.1, 'c', 2);
                        cacal = p1.zdmg
                    }
                    if (p1.class === 'archer') {
                        if (zip >= 1) {
                            anitext(p1.name + '용사의 집중사격!', 0.1, 'c', 2);
                            cacal = p1.zdmg * 1.3
                        } else {
                            anitext(p1.name + '용사의 사격!', 0.1, 'c', 2);
                            cacal = p1.zdmg
                        }

                    }
                    caca()
                    pturnend()
                    break;
                case '2':
                    //스킬
                    psk = 1
                    while (psk === 1) {
                        fui(cart)
                        process.stdout.write(chalk.cyan("[0.뒤로] "))
                        process.stdout.write(chalk.cyan("[s + n.스킬의 설명을 듣는다. 예시)s1] (패시브는 0)"))
                        br()
                        if (p1.class === 'warrior') {
                            if (p1.maxsch >= 1) { process.stdout.write(chalk.cyan("[1.내려찍기 -10] ")) }
                            if (p1.maxsch >= 2) { process.stdout.write(chalk.cyan("[2.불도저 -20] ")) }
                            if (p1.maxsch >= 3) { process.stdout.write(chalk.cyan("[3.윈드밀 -30] ")) }
                            if (p1.maxsch >= 4) { process.stdout.write(chalk.cyan("\n[4.방어태세 -0] ")) }
                            if (p1.maxsch >= 5) { process.stdout.write(chalk.cyan("[5.얼티밋 스워드 -100] ")) }
                            br()
                            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
                            let skchoice = readlineSync.question(' > ');
                            br()
                            if (skchoice === '10') { skchoice = '11' }
                            if (skchoice === '0') { skchoice = '10' }

                            if (skchoice === '1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === '2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === '3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === '4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === '5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === 's1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === 's2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === 's3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === 's4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === 's5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === '1' && p1.zmp < 10) { skchoice = '0' }
                            if (skchoice === '2' && p1.zmp < 20) { skchoice = '0' }
                            if (skchoice === '3' && p1.zmp < 30) { skchoice = '0' }
                            if (skchoice === '4' && p1.zmp < 0) { skchoice = '0' }
                            if (skchoice === '5' && p1.zmp < 100) { skchoice = '0' }

                            switch (skchoice) {
                                case '0':
                                    anitext('(숨이 턱 막힌다...)', 0.1, 'w', 2);
                                    psk = 0
                                    break;
                                case 's0':
                                    fui(cart)
                                    anitext('패시브 / 열&성', 0.1, 'c', 1);
                                    br()
                                    anitext('(최종 HP 1.5배, HP 회복량 1.5배, 공격력 + 1)', 0.1, 'c', 2);

                                    break;
                                case 's1':
                                    fui(cart)
                                    anitext('1.내려찍기 / mp 10소모 - 깡!', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.2배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(30% 침묵)침묵-다음 적 스킬불능', 0.1, 'c', 2);

                                    break;
                                case 's2':
                                    fui(cart)
                                    anitext('2.불도저 / mp 20소모 - 밀어버려잇', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.5배 피해를 입힌다.', 0.1, 'c', 2);

                                    break;
                                case 's3':
                                    fui(cart)
                                    anitext('3.윈드밀 / mp 30소모 - 어지러움 주의', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.8배 피해를 입힌다.', 0.1, 'c', 2);
                                    // anitext('(30% 침묵)침묵-다음 적 스킬불능', 0.1, 'c', 2);

                                    break;
                                case 's4':
                                    fui(cart)
                                    anitext('4.방어태세 / mp 0소모 - 우디르급 어쩌구', 0.1, 'c', 1);
                                    br()
                                    anitext('60% 확률로 태세를 전환해 다음 적의 공격을 막는다.', 0.1, 'c', 2);

                                    break;
                                case 's5':
                                    fui(cart)
                                    anitext('5.얼티밋 스워드 / mp 100소모 - 단죄하러 왔다.', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 적 최대체력 50%의 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(회피불가)', 0.1, 'c', 2);

                                    break;
                                case '1':
                                    psk = 0
                                    p1.zmp -= 10
                                    fui(cart)
                                    anitext('"세피로트를 위하여!"', 0.1, 'w', 2);
                                    // br()
                                    // anitext("랜덤값" + yrd, 0.1, 'c', 2);
                                    cacal = p1.zdmg * 1.2
                                    caca()
                                    if (cjj === 1) {
                                        yrd = Math.floor(Math.random() * 100) + 1
                                        if (yrd <= 30) {
                                            chk = "silence"
                                            br()
                                            chkc = 2
                                            fui(cart)
                                            anitext(cname + "(은)는 침묵에 걸렸다!", 0.1, 'c', 2);
                                        }
                                        if (yrd >= 98) {
                                            chk = "neutralize"
                                            br()
                                            chkc = 1
                                            fui(cart)
                                            anitext(cname + "(은)는 무력화 되었다!", 0.1, 'c', 2);
                                        }
                                    }

                                    pturnend()
                                    break;
                                case '2':
                                    psk = 0
                                    p1.zmp -= 20
                                    fui(cart)
                                    anitext('"돌격!"', 0.1, 'w', 2);
                                    cacal = p1.zdmg * 1.5
                                    caca()
                                    pturnend()
                                    break;
                                case '3':
                                    psk = 0
                                    p1.zmp -= 30
                                    fui(cart)
                                    anitext('"진형을 무너뜨려라!"', 0.1, 'w', 2);
                                    cacal = p1.zdmg * 1.8
                                    caca()
                                    pturnend()
                                    break;
                                case '4':
                                    psk = 0
                                    fui(cart)
                                    anitext('"확고한 의지로!"', 0.1, 'w', 2);
                                    yrd = Math.floor(Math.random() * 100) + 1
                                    if (yrd <= 60) {
                                        br()
                                        p1.zshi = 1
                                        anitext(p1.name + '용사는 태세를 전환했다!', 0.1, 'c', 2);
                                    } else {
                                        br()
                                        anitext('실패했다..', 0.1, 'c', 2);
                                    }
                                    pturnend()
                                    break;
                                case '5':
                                    psk = 0
                                    p1.zmp -= 100
                                    fui(cart)
                                    anitext('"대의를 위해!"', 0.3, 'w', 2);
                                    cacal = cmhp * 0.5
                                    chwp = 0
                                    caca()
                                    pturnend()
                                    break;
                                case '10':
                                    psk = 0
                                    break;
                                default:
                                    fui(cart)
                                    anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);

                            }

                        }
                        if (p1.class === 'defender') {
                            if (p1.maxsch >= 1) { process.stdout.write(chalk.cyan("[1.대쉬 -20] ")) }
                            if (p1.maxsch >= 2) { process.stdout.write(chalk.cyan("[2.방어 -10] ")) }
                            if (p1.maxsch >= 3) { process.stdout.write(chalk.cyan("[3.투척 -30] ")) }
                            if (p1.maxsch >= 4) { process.stdout.write(chalk.cyan("\n[4.반사 -10] ")) }
                            if (p1.maxsch >= 5) { process.stdout.write(chalk.cyan("[5.얼티밋 프로텍트 -100] ")) }
                            br()
                            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
                            let skchoice = readlineSync.question(' > ');
                            br()
                            if (skchoice === '10') { skchoice = '11' }
                            if (skchoice === '0') { skchoice = '10' }

                            if (skchoice === '1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === '2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === '3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === '4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === '5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === 's1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === 's2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === 's3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === 's4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === 's5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === '1' && p1.zmp < 20) { skchoice = '0' }
                            if (skchoice === '2' && p1.zmp < 10) { skchoice = '0' }
                            if (skchoice === '3' && p1.zmp < 30) { skchoice = '0' }
                            if (skchoice === '4' && p1.zmp < 10) { skchoice = '0' }
                            if (skchoice === '5' && p1.zmp < 100) { skchoice = '0' }

                            switch (skchoice) {
                                case '0':
                                    anitext('(숨이 턱 막힌다...)', 0.1, 'w', 2);
                                    psk = 0
                                    break;
                                case 's0':
                                    fui(cart)
                                    anitext('패시브 / 내가 그대들의 방패라네', 0.1, 'c', 1);
                                    br()
                                    anitext('(방어력 + LV*1, 공격력의 0.5 만큼 방어력 추가, 기본공격은 방어력의 1.0 데미지)', 0.1, 'c', 2);
                                    break;
                                case 's1':
                                    fui(cart)
                                    anitext('1.대쉬 / mp 20소모 - 방패로 공격하면 최고의 공격이 아닌가!', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.5배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(30% 무력화)-적 행동불능', 0.1, 'c', 2);
                                    break;
                                case 's2':
                                    fui(cart)
                                    anitext('2.방어 / mp 10소모 - 무기가 방패인데?', 0.1, 'c', 1);
                                    br()
                                    anitext('다음 적의 공격을 막는다.', 0.1, 'c', 2);
                                    break;
                                case 's3':
                                    fui(cart)
                                    anitext('3.투척 / mp 30소모 - 방패에 별 마크 없음니다..', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.5배 피해를 입힌다.', 0.1, 'c', 2);
                                    break;
                                case 's4':
                                    fui(cart)
                                    anitext('4.반사 / mp 10소모 - 성스러운 방어막 방패의 힘', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 받은 피해만큼 적에게 피해를 준다.', 0.1, 'c', 2);
                                    break;
                                case 's5':
                                    fui(cart)
                                    anitext('5.얼티밋 프로텍트 / mp 100소모 - 방어 그리고 또 방어', 0.1, 'c', 1);
                                    br()
                                    anitext('3턴동안 적을 무력화 합니다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(100% 무력화)-적 행동불능 / (회피불가)', 0.1, 'c', 2);

                                    break;
                                case '1':
                                    psk = 0
                                    p1.zmp -= 20
                                    fui(cart)
                                    anitext('"방패로 맞아보긴 처음이지?"', 0.1, 'w', 2);
                                    cacal = p1.zdef * 1.1
                                    caca()
                                    if (cjj === 1) {
                                        yrd = Math.floor(Math.random() * 100) + 1
                                        if (yrd <= 30) {
                                            chk = "neutralize"
                                            br()
                                            chkc = 1
                                            fui(cart)
                                            anitext(cname + "(은)는 무력화 되었다!", 0.1, 'c', 2);
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '2':
                                    psk = 0
                                    p1.zmp -= 10
                                    fui(cart)
                                    anitext('"뭐든지 막아보이겠어!"', 0.1, 'w', 2);
                                    p1.zshi = 1
                                    pturnend()
                                    break;
                                case '3':
                                    psk = 0
                                    p1.zmp -= 30
                                    fui(cart)
                                    anitext('"그렇겐 안 되지!"', 0.1, 'w', 2);
                                    cacal = p1.zdef * 1.5
                                    caca()
                                    pturnend()
                                    break;
                                case '4':
                                    psk = 0
                                    p1.zmp -= 10
                                    fui(cart)
                                    anitext('"설마 겨우 그거야?"', 0.1, 'w', 2);
                                    bansa = 1
                                    pturnend()
                                    break;
                                case '5':
                                    psk = 0
                                    p1.zmp -= 100
                                    fui(cart)
                                    anitext('"전투는 이렇게 하는 거다!"', 0.3, 'w', 2);
                                    chk = "neutralize"
                                    br()
                                    chkc = 3
                                    fui(cart)
                                    anitext(cname + "(은)는 무력화 되었다!", 0.1, 'c', 2);
                                    pturnend()
                                    break;
                                case '10':
                                    psk = 0
                                    break;
                                default:
                                    fui(cart)
                                    anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);

                            }

                        }
                        if (p1.class === 'magiccaster') {
                            if (p1.maxsch >= 1) { process.stdout.write(chalk.cyan("[1.파이어 볼 -30] ")) }
                            if (p1.maxsch >= 2) { process.stdout.write(chalk.cyan("[2.워터 캐논 -50] ")) }
                            if (p1.maxsch >= 3) { process.stdout.write(chalk.cyan("[3.포이즌 샤드 -70] ")) }
                            if (p1.maxsch >= 4) { process.stdout.write(chalk.cyan("\n[4.라이트닝 -120] ")) }
                            if (p1.maxsch >= 5) { process.stdout.write(chalk.cyan("[5.얼티밋 디스펠 200] ")) }
                            br()
                            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
                            let skchoice = readlineSync.question(' > ');
                            br()
                            if (skchoice === '10') { skchoice = '11' }
                            if (skchoice === '0') { skchoice = '10' }

                            if (skchoice === '1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === '2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === '3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === '4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === '5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === 's1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === 's2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === 's3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === 's4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === 's5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === '1' && p1.zmp < 30) { skchoice = '0' }
                            if (skchoice === '2' && p1.zmp < 50) { skchoice = '0' }
                            if (skchoice === '3' && p1.zmp < 70) { skchoice = '0' }
                            if (skchoice === '4' && p1.zmp < 120) { skchoice = '0' }
                            if (skchoice === '5' && p1.zmp < 200) { skchoice = '0' }

                            switch (skchoice) {
                                case '0':
                                    anitext('(숨이 턱 막힌다...)', 0.1, 'w', 2);
                                    psk = 0
                                    break;
                                case 's0':
                                    fui(cart)
                                    anitext('패시브 / 마법이 좋아요', 1, 'c', 1);
                                    br()
                                    anitext('(기본공격은 적에게 0.5 데미지, MP 2배, MP 회복량 2배)', 0.1, 'c', 2);

                                    break;
                                case 's1':
                                    fui(cart)
                                    anitext('1.파이어 볼 / mp 30소모 - 주의! 마시멜로 굽지 마세요', 0.1, 'c', 1);
                                    br()
                                    anitext('(속성공격:불) 작열 - 매 턴 적에게 공격력 0.1배 피해를 입힌다.', 0.1, 'c', 2);
                                    break;
                                case 's2':
                                    fui(cart)
                                    anitext('2.워터 캐논 / mp 50소모 - 물놀이 최강(여름 한정)', 0.1, 'c', 1);
                                    br()
                                    anitext('(속성공격:물) 수분 - 적에게 가하는 데미지가 10% 증폭된다.', 0.1, 'c', 2);
                                    break;
                                case 's3':
                                    fui(cart)
                                    anitext('3.포이즌 샤드 / mp 70소모 - 전염병 퍼져요..', 0.1, 'c', 1);
                                    br()
                                    anitext('(속성공격:독) 중독 - 매 턴 적에게 적 최대체력의 0.1배 피해를 입힌다.', 0.1, 'c', 2);
                                    break;
                                case 's4':
                                    fui(cart)
                                    anitext('4.라이트닝 / mp 70소모 손이 저려..', 0.1, 'c', 1);
                                    br()
                                    anitext('(속성공격:번개) 감전 - 적 행동 불가.', 0.1, 'c', 2);
                                    break;
                                case 's5':
                                    fui(cart)
                                    anitext('5.얼티밋 디스펠 / mp 200소모 - ', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 2배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('속성이 있는 적에게는 공격력의 3배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(회피불가)', 0.1, 'c', 2);
                                    break;
                                case '1':
                                    psk = 0
                                    p1.zmp -= 30
                                    fui(cart)
                                    anitext('"가랏, 파이어볼!"', 0.1, 'w', 2);
                                    if (chk === "") {//불 기본 - 50% 작열
                                        cacal = p1.zdmg * 1.1
                                        caca()
                                        if (cjj === 1) {
                                            yrd = Math.floor(Math.random() * 100) + 1
                                            if (yrd <= 50) {
                                                chk = "burn"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 불타오른다!", 0.1, 'c', 2);
                                            }
                                        }

                                    } else {
                                        if (chk === "burn") {//작열 + 불 - 1턴 추가
                                            cacal = p1.zdmg * 1.1
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 불타오른다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "moist") {//수분해제 0.9
                                            cacal = p1.zdmg * 0.9
                                            caca()
                                            if (cjj === 1) {
                                                chkc = 0
                                                chk = ""
                                                fui(cart)
                                                anitext(cname + "의 수분이 증발했다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "poison") {//중독해제 1.5
                                            cacal = p1.zdmg * 1.5
                                            caca()
                                            if (cjj === 1) {
                                                chkc = 0
                                                chk = ""
                                                fui(cart)
                                                anitext(cname + "의 중독이 사라졌다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "shock") {//감전 1딜
                                            cacal = p1.zdmg
                                            caca()
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '2':
                                    psk = 0
                                    p1.zmp -= 50
                                    fui(cart)
                                    anitext('"엘 시하!"', 0.1, 'w', 2);
                                    if (chk === "") {//물 기본 - 50% 수분
                                        cacal = p1.zdmg * 0.8
                                        caca()
                                        if (cjj === 1) {
                                            yrd = Math.floor(Math.random() * 100) + 1
                                            if (yrd <= 50) {
                                                chk = "moist"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 물에 젖었다!", 0.1, 'c', 2);
                                            }
                                        }
                                    } else {
                                        if (chk === "burn") {//작열 + 물 - 작열해제
                                            cacal = p1.zdmg
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 불타오른다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "moist") {//수분 추가
                                            cacal = p1.zdmg * 0.8
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 물에 젖었다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "poison") {//중독 1
                                            cacal = p1.zdmg
                                            caca()
                                        }
                                        if (chk === "shock") {//감전 1딜
                                            cacal = p1.zdmg + 10
                                            caca()
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '3':
                                    psk = 0
                                    p1.zmp -= 70
                                    fui(cart)
                                    anitext('"그거 좀 따끔할거야!"', 0.1, 'w', 2);
                                    if (chk === "") {//독 기본 - 30% 중독
                                        cacal = p1.zdmg * 1.2
                                        caca()
                                        if (cjj === 1) {
                                            yrd = Math.floor(Math.random() * 100) + 1
                                            if (yrd <= 30) {
                                                chk = "poison"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 중독되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                    } else {
                                        if (chk === "burn") {//작열 + 독 - 폭발
                                            cacal = p1.zdmg + 15
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 폭발했다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "poison") {//중독 추가
                                            cacal = p1.zdmg
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 중독되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "moist") {//수분 확정중독
                                            cacal = p1.zdmg + 10
                                            caca()
                                            if (cjj === 1) {
                                                chk = "poison"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 중독되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "shock") {//감전 1딜
                                            cacal = p1.zdmg
                                            caca()
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '4':
                                    psk = 0
                                    p1.zmp -= 120
                                    fui(cart)
                                    anitext('"<뇌정이여>, <자색 빛 번개의 충격으로써>, <때려눕혀라>"', 0.1, 'w', 2);
                                    if (chk === "") {//물 기본 - 50% 수분
                                        cacal = p1.zdmg * 1.5
                                        caca()
                                        if (cjj === 1) {
                                            yrd = Math.floor(Math.random() * 100) + 1
                                            if (yrd <= 20) {
                                                chk = "shock"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 감전되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                    } else {
                                        if (chk === "burn") {//작열
                                            cacal = p1.zdmg
                                            caca()
                                        }
                                        if (chk === "shock") {//감전 1딜
                                            cacal = p1.zdmg * 1.5
                                            caca()
                                            if (cjj === 1) {
                                                chkc++
                                                fui(cart)
                                                anitext(cname + "(은)는 감전되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "moist") {//수분 
                                            cacal = p1.zdmg * 1.8
                                            caca()
                                            if (cjj === 1) {
                                                chk = "shock"
                                                chkc = 2
                                                fui(cart)
                                                anitext(cname + "(은)는 감전되었다!", 0.1, 'c', 2);
                                            }
                                        }
                                        if (chk === "poison") {//중독 1
                                            cacal = p1.zdmg
                                            caca()
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '5':
                                    psk = 0
                                    p1.zmp -= 200
                                    fui(cart)
                                    anitext('"정화의 빛으로!"', 0.3, 'w', 2);
                                    chwp = 0
                                    if (chk === "") {
                                        cacal = cmhp * 2
                                        caca()
                                        anitext('적을 정화하였다!', 0.1, 'c', 2);
                                    } else {
                                        chk = ""
                                        cacal = cmhp * 3
                                        caca()
                                        anitext('적을 강하게 정화하였다!', 0.1, 'c', 2);
                                    }
                                    pturnend()
                                    break;
                                case '10':
                                    psk = 0
                                    break;
                                default:
                                    fui(cart)
                                    anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);

                            }

                        }
                        if (p1.class === 'rogue') {
                            if (p1.maxsch >= 1) { process.stdout.write(chalk.cyan("[1. 암습 -20] ")) }
                            if (p1.maxsch >= 2) { process.stdout.write(chalk.cyan("[2.연막 -20] ")) }
                            if (p1.maxsch >= 3) { process.stdout.write(chalk.cyan("[3.약점 공격 -40] ")) }
                            if (p1.maxsch >= 4) { process.stdout.write(chalk.cyan("\n[4.연격 -50] ")) }
                            if (p1.maxsch >= 5) { process.stdout.write(chalk.cyan("[5.얼티밋 킬러 -100 ] ")) }
                            br()
                            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
                            let skchoice = readlineSync.question(' > ');
                            br()
                            if (skchoice === '10') { skchoice = '11' }
                            if (skchoice === '0') { skchoice = '10' }

                            if (skchoice === '1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === '2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === '3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === '4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === '5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === 's1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === 's2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === 's3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === 's4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === 's5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === '1' && p1.zmp < 20) { skchoice = '0' }
                            if (skchoice === '2' && p1.zmp < 20) { skchoice = '0' }
                            if (skchoice === '3' && p1.zmp < 40) { skchoice = '0' }
                            if (skchoice === '4' && p1.zmp < 50) { skchoice = '0' }
                            if (skchoice === '5' && p1.zmp < 100) { skchoice = '0' }

                            switch (skchoice) {
                                case '0':
                                    anitext('(숨이 턱 막힌다...)', 0.1, 'w', 2);
                                    psk = 0
                                    break;
                                case 's0':
                                    fui(cart)
                                    anitext('패시브 / 신속', 0.1, 'c', 1);
                                    br()
                                    anitext('(속도 1.5배, HP 0.5배, 적의 공격 35% 회피)', 0.1, 'c', 2);

                                    break;
                                case 's1':
                                    fui(cart)
                                    anitext('1.암습 / mp 20소모 - 쉿', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.5배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(5% 적 즉사)', 0.1, 'c', 2);
                                    break;
                                case 's2':
                                    fui(cart)
                                    anitext('2연막 / mp 20소모 - 어디있게?', 0.1, 'c', 1);
                                    br()
                                    anitext('다음 적의 공격을 회피한다.', 0.1, 'c', 2);
                                    break;
                                case 's3':
                                    fui(cart)
                                    anitext('3.약점 공격 / mp 40소모 - 푹직', 0.1, 'c', 1);
                                    br()
                                    anitext('적 현제 체력의 20% 피해를 입힌다.', 0.1, 'c', 2);
                                    break;
                                case 's4':
                                    fui(cart)
                                    anitext('4.연격 / mp 50소모 - 죽어라', 0.1, 'c', 1);
                                    br()
                                    anitext('공격력 만큼 연속으로 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(연격 확률 40%, 반복 가능)', 0.1, 'c', 2);
                                    break;
                                case 's5':
                                    fui(cart)
                                    anitext('5.얼티밋 킬러 / mp 100소모 - 레디 투 다이', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 2배 피해를 입히고 체력이 낮으면 처형시킨다. (회피불가)', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(처형 - 적 현제 체력이 자신의 공격력 * 2 보다 낮으면 즉사)', 0.1, 'c', 2);

                                    break;
                                case '1':
                                    psk = 0
                                    p1.zmp -= 20
                                    fui(cart)
                                    anitext('"뒤를 조심해"', 0.1, 'w', 2);
                                    cacal = p1.zdmg * 1.5
                                    caca()
                                    if (cjj === 1) {
                                        yrd = Math.floor(Math.random() * 100) + 1
                                        if (yrd <= 6) {
                                            chp = 0
                                            fui(cart)
                                            anitext(cname + "(은)는 암습에 당했다!", 0.1, 'c', 2);
                                        }
                                    }
                                    pturnend()
                                    break;
                                case '2':
                                    psk = 0
                                    p1.zmp -= 20
                                    fui(cart)
                                    anitext('"필연은 막을 수 없지."', 0.1, 'w', 1);
                                    p1.hwp = 1
                                    pturnend()
                                    break;
                                case '3':
                                    psk = 0
                                    p1.zmp -= 40
                                    fui(cart)
                                    anitext('"밤길 조심하라고."', 0.1, 'w', 2);
                                    cacal = chp * 0.2
                                    caca()
                                    pturnend()
                                    break;
                                case '4':
                                    psk = 0
                                    p1.zmp -= 50
                                    fui(cart)
                                    anitext('"단도는 많을수록 좋지."', 0.1, 'w', 2);
                                    cacal = p1.zdmg
                                    caca()
                                    ygc = 1
                                    yrd = Math.floor(Math.random() * 100) + 1
                                    while (yrd <= 40) {
                                        ygc++
                                        caca()
                                        yrd = Math.floor(Math.random() * 100) + 1
                                    }
                                    br()
                                    anitext(ygc + '번 공격했다.', 0.1, 'c', 2);
                                    pturnend()
                                    break;
                                case '5':
                                    psk = 0
                                    p1.zmp -= 100
                                    fui(cart)
                                    anitext('"슬슬 마무리하지."', 0.3, 'w', 2);
                                    cacal = p1.zdmg * 2
                                    chwp = 0
                                    caca()
                                    if (chp < (p1.zdmg * 2)) { chp = 0 }
                                    fui(cart)
                                    anitext(cname + "(은)는 처형 당했다!", 0.1, 'c', 2);
                                    pturnend()
                                    break;
                                case '10':
                                    psk = 0
                                    break;
                                default:
                                    fui(cart)
                                    anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);

                            }

                        }
                        if (p1.class === 'archer') {
                            if (p1.maxsch >= 1) { process.stdout.write(chalk.cyan("[1. 해드샷 -30] ")) }
                            if (p1.maxsch >= 2) { process.stdout.write(chalk.cyan("[2.집중 -10] ")) }
                            if (p1.maxsch >= 3) { process.stdout.write(chalk.cyan("[3.속사 -50] ")) }
                            if (p1.maxsch >= 4) { process.stdout.write(chalk.cyan("\n[4.로빈애로우 -70] ")) }
                            if (p1.maxsch >= 5) { process.stdout.write(chalk.cyan("[5.얼티밋 궁수 -100 ] ")) }
                            br()
                            anitext(p1.name + '용사의 행동은?', 0.1, 'c', 0.1);
                            let skchoice = readlineSync.question(' > ');
                            br()
                            if (skchoice === '10') { skchoice = '11' }
                            if (skchoice === '0') { skchoice = '10' }

                            if (skchoice === '1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === '2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === '3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === '4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === '5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === 's1' && p1.maxsch < 1) { skchoice = '11' }
                            if (skchoice === 's2' && p1.maxsch < 2) { skchoice = '11' }
                            if (skchoice === 's3' && p1.maxsch < 3) { skchoice = '11' }
                            if (skchoice === 's4' && p1.maxsch < 4) { skchoice = '11' }
                            if (skchoice === 's5' && p1.maxsch < 5) { skchoice = '11' }

                            if (skchoice === '1' && p1.zmp < 30) { skchoice = '0' }
                            if (skchoice === '2' && p1.zmp < 10) { skchoice = '0' }
                            if (skchoice === '3' && p1.zmp < 50) { skchoice = '0' }
                            if (skchoice === '4' && p1.zmp < 70) { skchoice = '0' }
                            if (skchoice === '5' && p1.zmp < 100) { skchoice = '0' }

                            switch (skchoice) {
                                case '0':
                                    anitext('(숨이 턱 막힌다...)', 0.1, 'w', 2);
                                    psk = 0
                                    break;
                                case 's0':
                                    fui(cart)
                                    anitext('패시브 / 신궁', 0.1, 'c', 1);
                                    br()
                                    anitext('(화살을 소비하지 않는다, 공격력 1.2배, 항상 선제공격)', 0.1, 'c', 2);

                                    break;
                                case 's1':
                                    fui(cart)
                                    anitext('1.해드샷 / mp 30소모 - 니 머리에 한 방', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 1.5배 피해를 입힌다.', 0.1, 'c', 2);
                                    break;
                                case 's2':
                                    fui(cart)
                                    anitext('2.집중 / mp 10소모 - 준비된 사수로부터-', 0.1, 'c', 1);
                                    br()
                                    anitext('3턴동안 기본공격의 데미지 1.3배', 0.1, 'c', 2);
                                    break;
                                case 's3':
                                    fui(cart)
                                    anitext('3.속사 / mp 50소모 - 손 힘이 대단한데?', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 2배 + 속도 피해를 입힌다.', 0.1, 'c', 0.1);
                                    // anitext('(속도 비례 데미지 증가)', 0.1, 'c', 2);
                                    break;
                                case 's4':
                                    fui(cart)
                                    anitext('4.로빈애로우 / mp 70소모 아픈 곳 또 찌르기', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력 + 속도의 2.4배 피해를 입힌다.', 0.1, 'c', 2);
                                    br()
                                    anitext('(회피불가)', 0.1, 'c', 2);
                                    break;
                                case 's5':
                                    fui(cart)
                                    anitext('5.얼티밋 궁수 / mp 100소모 - 당신에게 활의 축복을', 0.1, 'c', 1);
                                    br()
                                    anitext('적에게 공격력의 5배 피해를 입힌다.', 0.1, 'c', 0.1);
                                    br()
                                    anitext('(회피불가)', 0.1, 'c', 2);
                                    break;
                                case '1':
                                    psk = 0
                                    p1.zmp -= 30
                                    fui(cart)
                                    anitext('"너에게 닿기를..!"', 0.1, 'w', 2);
                                    cacal = p1.zdmg * 1.5
                                    caca()
                                    pturnend()
                                    break;
                                case '2':
                                    psk = 0
                                    p1.zmp -= 10
                                    fui(cart)
                                    anitext('"..."', 0.1, 'w', 1);
                                    zip = 3
                                    br()
                                    anitext('집중을 하여 기본공격이 강해졌다.', 0.1, 'c', 2);
                                    pturnend()
                                    break;
                                case '3':
                                    psk = 0
                                    p1.zmp -= 50
                                    fui(cart)
                                    anitext('"...놓치지 않아."', 0.1, 'w', 2);
                                    cacal = (p1.zdmg * 2) + p1.zspd
                                    caca()
                                    pturnend()
                                    break;
                                case '4':
                                    psk = 0
                                    p1.zmp -= 70
                                    fui(cart)
                                    anitext('"빗나가지 않아."', 0.1, 'w', 2);
                                    chwp = 0
                                    cacal = (p1.zdmg + p1.zspd) * 2.4
                                    caca()
                                    pturnend()
                                    break;
                                case '5':
                                    psk = 0
                                    p1.zmp -= 100
                                    fui(cart)
                                    anitext('"사악을 분쇄하는 정의의 일격!"', 0.3, 'w', 2);
                                    cacal = p1.zdmg * 5
                                    chwp = 0
                                    caca()
                                    pturnend()
                                    break;
                                case '10':
                                    psk = 0
                                    break;
                                default:
                                    fui(cart)
                                    anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);

                            }

                        }
                    }
                    // process.stdout.write(chalk.cyan("1.내려찍기 -10 2.불도저 -20 3.윈드밀 -30 4.방어태세 -0 5.얼티밋 스워드 -100"))
                    break;
                case '3':
                    //인벤토리
                    fui(cart)
                    anitext('인벤토리를 열었다.', 0.1, 'c', 1);
                    fui(cart)
                    anitext('인벤토리에 아이템이 없다.', 0.1, 'c', 2);
                    // turn++
                    // pturn = 0
                    break;
                case '4':
                    //도망
                    fui(cart)
                    anitext(cname + '(으)로부터 도망쳤다.', 0.1, 'c', 3);
                    pturn = 0
                    ft = 0
                    break;
                default:
                    anitext('다시 입력하세요', 0.1, 'c', 1);
            }
            if (chp <= 0) {
                fui(cart)
                anitext(ctk2, 0.1, 'w', 2);
                br()
                anitext(cname + '(을)를 물리쳤다!', 0.1, 'c', 3);
                cl()
                ft = 0
            }
            if (p1.zhp <= 0) {
                fui(cart)
                anitext("크윽...", 0.1, 'w', 2);
                br()
                anitext(p1.name + '용사는 쓰러졌다.', 0.1, 'c', 3);
                cl()
                pturn = 0
                ft = 0
            }

        }
    }
    fui(cart)
    p1.exp += cexp
    p1.gold += cgold
    anitext(cgold + '골드와 ' + cexp + '경험치를 획득했다.', 0.1, 'c', 2);

    //경험치 > 레벨

    ilvup = 0
    if (p1.exp >= (p1.lv * 10)) {
        ilvup = 1
        p1.exp -= (p1.lv * 10)
        p1.lv++
        br()
        anitext(p1.name + '용사는 성장했다! (' + (p1.lv - 1) + ' > ' + p1.lv + ')', 0.1, 'c', 1);
    }
    while (ilvup === 1) {
        if (p1.exp >= (p1.lv * 10)) {
            p1.exp -= (p1.lv * 10)
            p1.lv++
        }
        if (p1.exp < (p1.lv * 10)) {
            ilvup = 0
        }
    }
    br()
    anitext('레벨 : ' + p1.lv, 0.1, 'c', 1);

}



function fgame() {
    sleep(1)
    cl()
    anitext('...', 1, "w", 1);
    br()
    anitext('Detecting language...', 0.3, "g", 1);
    br()
    anitext('Language detected : Korean', 0.1, "b", 3);
    cl()
    aniprt('code')
    anitext('안녕하세요! ', 0.1, "c", 1);
    anitext('제 소개를 먼저 할게요.', 0.1, "c", 1);
    br();
    anitext('저는 앞으로 당신의 게임 진행을 도와드릴', 0.1, 'c', 0.1);
    br();
    anitext('Reads Scenarios and Helps For Play Game Code', 0.02, 'b', 1);
    br();
    anitext('어...', 0.1, 'c', 1);
    anitext('그냥 코드씨 라고 불러주세요!', 0.1, 'c', 2);
    cl()
    aniprt('code')
    anitext('아무튼!', 0.1, 'y', 1);
    br()
    anitext('게임 설명이나 마저 하겠습니다.', 0.15, 'c', 2);
    cl()
    aniprt('code')
    anitext('제가 하는 말에 앞 뒤에는', 0.1, 'c', 0.1);
    anitext('""', 0.1, 'w', 0.1);
    anitext('특수문자가 뜨지 않습니다.', 0.1, 'c', 1);
    br()
    anitext('반대로 게임 속 등장인물의 대사에는', 0.1, "c", 0.1);
    anitext('""', 0.1, 'w', 0.1);
    anitext('특수문자가 표시됩니다.', 0.1, 'c', 1);
    br()
    anitext('이제', 0.1, 'c', 0.1);
    anitext(' y ', 0.1, 'y', 0.1);
    anitext('를 입력하면 프롤로그를 진행합니다.', 0.1, 'c', 0.1);
    br()
    anitext('넘기려면', 0.1, 'c', 0.1);
    anitext(' n ', 0.1, 'y', 0.1);
    anitext('을 입력하면 프롤로그를 스킵합니다.', 0.1, 'c', 0.1);
    //입력문
    let skip = 0;
    for (var i = 0; i === 0;) {
        br();
        const mchoice = readlineSync.question(' > ');
        switch (mchoice) {
            case 'y':
                anitext('재미있게 감상 해주세요.', 0.1, 'c', 1);
                i++
                break;
            case 'n':
                // anitext('미구현', 0.1, 'c', 1);
                anitext('나의 이름은..?', 0.3, 'w', 0.5);
                //입력문
                for (var i = 0; i === 0;) {
                    const mchoice = readlineSync.question(' > ');
                    switch (mchoice) {
                        default:
                            p1.name = mchoice;
                            i++
                    }
                }
                skip = 1;
                i++
                break;
            default:
                anitext('다시 입력하세요', 0.1, 'c', 1);
                cl()
        }
    }
    if (skip === 0) {
        cl()
        anitext('Chapter : Prologue', 0.2, 'g', 1);
        br()
        br()
        //텍스트 그림 넣을레?
        anitext('어느 화창한 오후', 0.1, 'c', 1);
        br()
        anitext('방구석 겜창인 ', 0.1, 'c', 0.5);
        anitext('오늘의 주인공이 있습니다. ', 0.1, 'c', 0.1);
        br()
        anitext('이벤트를 달리느라 ', 0.1, 'c', 0.3);
        br()
        anitext('오늘 하루도 잠을 안 자고 ', 0.1, 'c', 0.3);
        br()
        anitext('게임만 하는군요', 0.2, 'c', 1);
        cl()
        anitext('"이벤트 다 달렸다.."', 0.2, 'w', 0.1);
        br()
        anitext('(꼬르륵)', 0.1, 'w', 2);
        br()
        anitext('"아, ', 0.2, 'w', 0.5);
        anitext('점심 뭐 먹지.."', 0.1, 'w', 1);
        br()
        anitext('아무리 인간 말종이지만 ', 0.1, 'c', 0.3);
        anitext('꼴에 배꼽시계는 정상작동 하는군요', 0.1, 'c', 1.5);
        br()
        anitext('"아-', 0.3, 'w', 0.5);
        anitext('맞다', 0.3, 'w', 0.5);
        anitext(' 편의점에서 빵 콜라보 했지.."', 0.1, 'w', 1);
        br()
        anitext('당신은 빵을 사기 위해 ', 0.05, 'c', 0.5);
        anitext('편의점으로 향합니다.', 0.1, 'c', 1);
        cl()
        anitext('(2시간 뒤)', 0.1, 'b', 1);
        br()
        anitext('10군데가 넘는 편의점을 다니고 11번째 편의점에 도착합니다.', 0.1, 'c', 1);
        br()
        anitext('이런, ', 0.1, 'c', 0.5);
        anitext('이번 편의점에도 빵이 품절이군요', 0.1, 'c', 0.5);
        br()
        anitext('"...', 0.4, 'w', 1);
        anitext('하아..', 0.1, 'w', 1);
        anitext('벌써 몇 번째 편의점이야"', 0.1, 'w', 1);
        br()
        anitext('"하나쯤은 있을법 한데 X발"', 0.1, 'w', 1);
        br()
        anitext('다른 편의점으로 가야겠네요.', 0.1, 'c', 2);
        cl()
        anitext('아쉬운 마음을 뒤로 한 체 ', 0.1, 'c', 0.5);
        anitext('다른 편의점으로 가던 당신은', 0.1, 'c', 1.5);
        br()
        anitext('피로에 쩔어', 0.1, 'c', 0.3);
        anitext(' 신호등을 건너던 도중', 0.1, 'c', 0.3);
        br()
        anitext('(철푸덕)', 0.1, 'w', 0.3);
        br()
        anitext('바닥에 곤두박질칩니다', 0.1, 'c', 2);
        br()
        anitext('"...아', 0.4, 'w', 0.5);
        anitext('...마지막으로 잔게 언제였더라..."', 0.2, 'w', 0.3);
        br()
        anitext('(빠아앙~!)', 0.1, 'c', 1);

        cl()
        console.log("□□□■■■■■■■□□■□□□□□\n□□□□□□□□□■□□■□□□□□\n□□□■■■■■■■□□■□□□□□\n□□□□□□□□□■□□■■■□□□\n□□□□□□■□□■□□■□□□□□\n□□□□□□■□□■□□■□□□□□\n□□□■■■■■■■■■■□□□□□\n□□□□□□■■■■■■□□□□□□\n□□□□□■■□□□□■■□□□□□\n□□□□□■□□□□□□■□□□□□\n□□□□□■■□□□□■■□□□□□\n□□□□□□■■■■■■□□□□□□\n")
        sleep(3)
        cl()
        anitext('...', 0.5, 'c', 1);
        anitext('트럭에 치여 사망합니다.', 0.1, 'c', 1);
        cl()
        anitext('눈 앞이 캄캄합니다.', 0.1, 'c', 3);
        cl()
        anitext('"..님..."', 0.2, 'w', 1);
        br()
        anitext('어둠속에서 누군가의 목소리가 들려옵니다.', 0.1, 'c', 3);
        cl()
        anitext('"용사...', 0.2, 'w', 0.5);
        anitext(' 어나세요..."', 0.2, 'w', 1);
        cl()
        aniprt('mio')
        anitext('"깨어나세요', 0.2, 'w', 0.3);
        anitext(' 용사님"', 0.2, 'w', 1);
        br()
        anitext('눈을 떠보니', 0.1, 'c', 0.3);
        anitext(' 아름다운 미모의 여성이', 0.1, 'c', 0.3);
        anitext(' 당신에게 말을 건넵니다.', 0.1, 'c', 0.3);
        cl()
        aniprt('mio')
        anitext('"아, 정신이 드셨나요?"', 0.1, 'w', 1);
        br()
        anitext('"여긴.. ', 0.3, 'w', 0.5);
        anitext('어..디죠?"', 0.2, 'w', 1);
        br()
        anitext('"이곳은 이계입니다."', 0.1, 'w', 1);
        br()
        anitext('"이계..?"', 0.3, 'w', 2);
        cl()
        aniprt('mio')
        anitext('오타쿠처럼 게임만 하다 죽어서 그런지 헛것이 보이는 느낌이네요', 0.1, 'c', 0.5);
        anitext(' 하!하!하!', 0.5, 'c', 1);
        cl()
        aniprt('mio')
        anitext('"정신이 온전하신 상태가 아니군요.."', 0.1, 'w', 2);
        br()
        anitext('"저의 이름은 아인"', 0.1, 'w', 1);
        br()
        anitext('"용사님의 이름은 무엇인가요?"', 0.1, 'w', 1);
        cl()
        anitext('"나의 이름은..?', 0.4, 'w', 0.5);
        //입력문
        for (var i = 0; i === 0;) {
            const choice1 = readlineSync.question(' > ');
            switch (choice1) {
                default:
                    p1.name = choice1;
                    i++
            }
        }
        anitext('입니다."', 0.1, 'w', 1);
        cl()
        aniprt('mio')
        anitext('"' + p1.name + '용사님..."', 0.1, 'w', 1);
        br()
        anitext('"이계 세피로트는 지금 위기에 처해있습니다."', 0.1, 'w', 1);
        br()
        anitext('"' + p1.name + '용사님의 도움이 필요합니다."', 0.1, 'w', 1);
        br()
        anitext('"부디.. 세피로트를 구원해주세요"', 0.1, 'w', 1);
        cl()
        aniprt('mio')
        anitext('뭔지 모를 소리만 늘어놓는 이상한 사람이군요', 0.1, 'c', 1);
        br()
        anitext('"네..?!"', 0.1, 'w', 1);
        br()
        anitext('"무운을 빕니다."', 0.1, 'w', 1);
        br()
        anitext('"아니 잠ㄲ.."', 0.1, 'w', 1);
    }
    cl()
    anitext('당신은 빛에 휩싸이기 시작합니다.', 0.1, 'c', 2);
    br()
    anitext('■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n', 0.01, 'c', 2);
    cl()
    anitext('눈을 떠보니 하늘이 보입니다.', 0.1, 'c', 1);
    br()
    anitext(p1.name + '용사님 누워계시군요..?', 0.2, 'c', 1);
    anitext('(크흠)', 0.1, 'c', 1);
    br()
    anitext('정말 아름다운 날입니다.', 0.1, 'c', 1);
    br()
    anitext('새들은 지저귀고, 꽃들은 피어나고...', 0.1, 'c', 2);
    br()
    anitext('(벌떡 일어난다)', 0.1, 'w', 0.5);
    br()
    anitext('"이게 뭐야;;"', 0.1, 'w', 1);
    br()
    anitext('어찌된 일인지 모르겠지만 우선 일어나기로 합니다.', 0.1, 'c', 2);
    cl()
    anitext('!!!', 0.1, 'c', 1);
    br()
    aniprt('wolf')
    anitext('늑대가 나타났습니다.', 0.1, 'c', 0.4);
    br()
    anitext('"갑자기?!"', 0.1, 'w', 2);
    br()
    cl()
    anitext('그러자 눈 앞에 무기가 생겨나기 시작합니다.', 0.1, 'c', 1);
    br()
    anitext('위기에 처한 당신은 우선 무기를 고르기로 합니다.', 0.1, 'c', 1);
    cl()
    anitext('(고르는 무기에 따라 직업이 결정됩니다.)', 0.1, 'b', 1);
    br()
    anitext('(1.검 2.방패 3.지팡이 4.단도 5.활)', 0.1, 'b', 1);
    br()
    for (var i = 0; i === 0;) {
        const choice2 = readlineSync.question(' > ');
        wepo = choice2;
        switch (choice2) {
            case '1':
                anitext('검을 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                p1.class = 'warrior'
                p1.wepon = "ww1"
                i++
                break;
            case '2':
                anitext('방패를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                p1.class = 'defender'
                p1.wepon = "wd1"
                i++
                break;
            case '3':
                anitext('지팡이를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                p1.class = 'magiccaster'
                p1.wepon = "wm1"
                i++
                break;
            case '4':
                anitext('단도를 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                p1.class = 'rogue'
                p1.wepon = "wr1"
                i++
                break;
            case '5':
                anitext('활을 집어들자 나머지 무기가 사라집니다.', 0.1, 'c', 1);
                p1.class = 'archer'
                p1.wepon = "wa1"
                i++
                break;
            case '1324':
                anitext('당신.. 개발자군요?', 0.1, 'c', 1);
                p1.class = 'tenster'
                p1.hat = "h1"
                p1.armor = "a1"
                p1.shoes = "s1"
                p1.gloves = "g1"
                p1.pendant = "p1"
                p1.wepon = "w1"
                i++
                break;
            default:
                anitext(p1.name + '용사는 이해하지 못했다.', 0.1, 'c', 2);
                cl()
                console.log(chalk.blue('(고르는 무기에 따라 직업이 결정됩니다.)'));
                console.log(chalk.blue('(1.검 2.방패 3.지팡이 4.단도 5.활)'));
        }
    }
    sleep(5)
    checkitem()
    chokihwa()
    fight(wolf, 1)
    igame()
}
function igame() {
    cl()
    anitext('전투 다음에 어떤 스토리가 올까요?', 0.1, 'c', 2);
    br()
    anitext('양산형 이세계물 느낌나게 이것저것 만들어서 오도록 하겠습니다.', 0.1, 'c', 2);
    br()
    anitext('(뒷 이야기 준비 중...)', 0.3, 'b', 2);
}

// 게임 실행
start();