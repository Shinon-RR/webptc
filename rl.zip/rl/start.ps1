cd C:\Users\Administrator\Desktop\SPCODE\rl
node rl.js
pause